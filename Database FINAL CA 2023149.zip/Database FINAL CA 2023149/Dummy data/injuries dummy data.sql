INSERT INTO `nfl-149`.injuries (injuryType) VALUES
	 ('Foot'),
	 ('Knee'),
	 ('Hamstring'),
	 ('Ankle'),
	 ('Shoulder'),
	 ('Back'),
	 ('ThinghBack'),
	 ('Quadricep');
