INSERT INTO `nfl-149`.teams (teamName,city,captain,coach) VALUES
	 ('Buffalo Bills','Buffalo',19,'Sean McDermott'),
	 ('Cincinnati Bengals','Cincinnati',29,'Zac Taylor'),
	 ('Tennessee Titans','Nashville',44,'Mike Vrabel'),
	 ('Tampa Bay Buccaneers','Tampa',61,'Bruce Arians'),
	 ('Jacksonville Jaguars','Jacksonville',81,'Urban Meyer'),
	 ('Cleveland Browns','Cleveland',105,'Kevin Stefanski'),
	 ('Arizona Cardinals','Glendale',128,'Kliff Kingsbury'),
	 ('Los Angeles Chargers','Los Angeles',147,'Brandon Staley'),
	 ('Carolina Panthers','Charlotte',173,'Matt Rhule'),
	 ('Houston Texans','Houston',197,'David Culley');
