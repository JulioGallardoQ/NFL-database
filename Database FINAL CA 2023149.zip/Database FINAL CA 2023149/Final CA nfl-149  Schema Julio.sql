CREATE DATABASE  IF NOT EXISTS `nfl-149` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `nfl-149`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: nfl-149
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gameresults`
--

DROP TABLE IF EXISTS `gameresults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gameresults` (
  `id_gameResult` int NOT NULL AUTO_INCREMENT,
  `team` int NOT NULL,
  `game` int NOT NULL,
  `gameResult` varchar(20) NOT NULL,
  PRIMARY KEY (`id_gameResult`),
  KEY `Team(id)_idx` (`team`),
  KEY `Game(id)_idx` (`game`),
  CONSTRAINT `Game(id)` FOREIGN KEY (`game`) REFERENCES `games` (`id_Games`),
  CONSTRAINT `Team(id)` FOREIGN KEY (`team`) REFERENCES `teams` (`id_Team`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gameresults`
--

LOCK TABLES `gameresults` WRITE;
/*!40000 ALTER TABLE `gameresults` DISABLE KEYS */;
INSERT INTO `gameresults` VALUES (1,1,2,'Loss'),(2,1,6,'Draw'),(3,1,12,'Loss'),(4,1,18,'Win'),(5,2,3,'Draw'),(6,2,8,'Draw'),(7,2,11,'Loss'),(8,2,17,'Draw'),(9,3,1,'Win'),(10,3,6,'Draw'),(11,3,11,'Win'),(12,3,16,'Win'),(13,4,1,'Loss'),(14,4,7,'Loss'),(15,4,12,'Win'),(16,4,17,'Draw'),(17,5,5,'Win'),(18,5,10,'Draw'),(19,5,14,'Draw'),(20,5,19,'Loss'),(21,6,4,'Win'),(22,6,10,'Draw'),(23,6,15,'Win'),(24,6,20,'Win'),(25,7,2,'Win'),(26,7,8,'Draw'),(27,7,13,'Win'),(28,7,19,'Win'),(29,8,5,'Loss'),(30,8,7,'Win'),(31,8,15,'Loss'),(32,8,18,'Loss'),(33,9,4,'Loss'),(34,9,9,'Draw'),(35,9,13,'Loss'),(36,9,16,'Loss'),(37,10,3,'Draw'),(38,10,9,'Draw'),(39,10,14,'Draw'),(40,10,20,'Loss');
/*!40000 ALTER TABLE `gameresults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `games`
--

DROP TABLE IF EXISTS `games`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `games` (
  `id_Games` int NOT NULL,
  `id_Host_team` int NOT NULL,
  `id_Guest_Team` int NOT NULL,
  `gameDate` date NOT NULL,
  `host_Score` int NOT NULL,
  `guest_Score` int NOT NULL,
  PRIMARY KEY (`id_Games`),
  KEY `id_Host_Team_idx` (`id_Host_team`),
  KEY `id_Guest_Team_idx` (`id_Guest_Team`),
  CONSTRAINT `id_Guest_Team` FOREIGN KEY (`id_Guest_Team`) REFERENCES `teams` (`id_Team`),
  CONSTRAINT `id_Host_Team` FOREIGN KEY (`id_Host_team`) REFERENCES `teams` (`id_Team`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `games`
--

LOCK TABLES `games` WRITE;
/*!40000 ALTER TABLE `games` DISABLE KEYS */;
INSERT INTO `games` VALUES (1,3,4,'2022-08-29',14,7),(2,1,7,'2022-08-29',9,16),(3,2,10,'2022-08-30',21,21),(4,9,6,'2022-08-30',19,24),(5,5,8,'2022-09-01',24,16),(6,3,1,'2022-09-08',17,17),(7,4,8,'2022-09-08',14,16),(8,2,7,'2022-09-09',24,24),(9,9,10,'2022-09-09',15,15),(10,5,6,'2022-09-10',21,21),(11,3,2,'2022-09-14',24,17),(12,4,1,'2022-09-14',16,14),(13,9,7,'2022-09-15',9,21),(14,5,10,'2022-09-15',21,21),(15,6,8,'2022-09-16',19,15),(16,3,9,'2022-09-21',24,21),(17,4,2,'2022-09-21',16,16),(18,1,8,'2022-09-22',24,16),(19,5,7,'2022-09-22',7,19),(20,6,10,'2022-09-23',24,17);
/*!40000 ALTER TABLE `games` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `injuries`
--

DROP TABLE IF EXISTS `injuries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `injuries` (
  `id_Injuries` int NOT NULL AUTO_INCREMENT,
  `injuryType` varchar(45) NOT NULL,
  PRIMARY KEY (`id_Injuries`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `injuries`
--

LOCK TABLES `injuries` WRITE;
/*!40000 ALTER TABLE `injuries` DISABLE KEYS */;
INSERT INTO `injuries` VALUES (1,'Foot'),(2,'Knee'),(3,'Hamstring'),(4,'Ankle'),(5,'Shoulder'),(6,'Back'),(7,'ThinghBack'),(8,'Quadricep');
/*!40000 ALTER TABLE `injuries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `injuriesrecord`
--

DROP TABLE IF EXISTS `injuriesrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `injuriesrecord` (
  `id_InjuriesRecord` int NOT NULL AUTO_INCREMENT,
  `id_player` int NOT NULL,
  `id_injury` int NOT NULL,
  `injuryDate` date NOT NULL,
  PRIMARY KEY (`id_InjuriesRecord`),
  KEY `player id_idx` (`id_player`),
  KEY `injury id_idx` (`id_injury`),
  CONSTRAINT `injury id` FOREIGN KEY (`id_injury`) REFERENCES `injuries` (`id_Injuries`),
  CONSTRAINT `player id` FOREIGN KEY (`id_player`) REFERENCES `player` (`id_Player`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `injuriesrecord`
--

LOCK TABLES `injuriesrecord` WRITE;
/*!40000 ALTER TABLE `injuriesrecord` DISABLE KEYS */;
INSERT INTO `injuriesrecord` VALUES (1,55,1,'2022-08-29'),(2,22,2,'2022-08-29'),(3,150,5,'2022-08-31'),(4,101,8,'2022-09-01'),(5,115,5,'2022-09-02'),(6,55,4,'2021-08-29'),(7,180,3,'2021-08-29'),(8,95,3,'2021-08-29'),(9,73,2,'2021-08-29'),(10,55,5,'2021-10-15'),(11,140,5,'2021-10-16'),(12,199,6,'2021-10-17'),(13,55,1,'2020-08-13'),(14,147,2,'2020-08-14'),(15,55,5,'2019-09-20'),(16,69,5,'2019-09-21'),(17,37,4,'2019-09-22'),(18,14,1,'2019-09-23'),(19,55,4,'2019-09-24'),(20,135,3,'2019-09-25');
/*!40000 ALTER TABLE `injuriesrecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player`
--

DROP TABLE IF EXISTS `player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player` (
  `id_Player` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(15) NOT NULL,
  `lastName` varchar(15) NOT NULL,
  `Position` varchar(30) NOT NULL,
  `skill_Level` varchar(15) NOT NULL,
  `team` int NOT NULL,
  PRIMARY KEY (`id_Player`),
  KEY `id_team_idx` (`team`),
  CONSTRAINT `team id` FOREIGN KEY (`team`) REFERENCES `teams` (`id_Team`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player`
--

LOCK TABLES `player` WRITE;
/*!40000 ALTER TABLE `player` DISABLE KEYS */;
INSERT INTO `player` VALUES (1,'Isaiah','Coulter','Wide Receiver','Medium',1),(2,'Richard','Gouraige','Tackle','High ',1),(3,'Jordan','Phillips','Defensive Tackle','Low',1),(4,'Bryan','Thompson','Wide Receiver','High ',1),(5,'Tyrell','Shavers','Wide Receiver','Medium',1),(6,'Ryan','Bates','Offensive Lineman','High ',1),(7,'Dane','Jackson','Cornerback','Low',1),(8,'Poona','Ford','Defensive Tackle','High ',1),(9,'Khalil','Shakir','Wide Receiver','Medium',1),(10,'DaQuan','Jones','Defensive Tackle','High ',1),(11,'Justin','Shorter','Wide Receiver','Low',1),(12,'Tre\'Davious','White','Cornerback','High ',1),(13,'Shane','Ray','Linebacker','Medium',1),(14,'Taylor','Rapp','Safety','High ',1),(15,'Dorian','Williams','Linebacker','Low',1),(16,'Mitch','Morse','Center','High ',1),(17,'Nick','Broeker','Guard','Medium',1),(18,'Dion','Dawkins','Tackle','High ',1),(19,'Terrel','Bernard','Linebacker','Low',1),(20,'Dawson','Knox','Tight End','Medium',1),(21,'Joe','Burrow','Quarterback','Medium',2),(22,'Joe','Mixon','Running Back','High ',2),(23,'Ja\'Marr','Chase','Wide Receiver','Low',2),(24,'Tyler','Boyd','Wide Receiver','Medium',2),(25,'Tee','Higgins','Wide Receiver','High ',2),(26,'C.J.','Uzomah','Tight End','Low',2),(27,'Riley','Reiff','Offensive Tackle','Medium',2),(28,'Jonah','Williams','Offensive Tackle','High ',2),(29,'Trey','Hopkins','Center','Low',2),(30,'D.J.','Reader','Defensive Tackle','Medium',2),(31,'Larry','Ogunjobi','Defensive Tackle','High ',2),(32,'Sam','Hubbard','Defensive End','Low',2),(33,'Trey','Hendrickson','Defensive End','Medium',2),(34,'Logan','Wilson','Linebacker','High ',2),(35,'Germaine','Pratt','Linebacker','Low',2),(36,'Eli','Apple','Cornerback','Medium',2),(37,'Chidobe','Awuzie','Cornerback','High ',2),(38,'Jessie','Bates III','Safety','Low',2),(39,'Vonn','Bell','Safety','Medium',2),(40,'Evan','McPherson','Kicker','High ',2),(41,'Ryan','Tannehill','Quarterback','High ',3),(42,'Derrick','Henry','Running Back','Low',3),(43,'A.J.','Brown','Wide Receiver','Medium',3),(44,'Julio','Jones','Wide Receiver','High ',3),(45,'Josh','Reynolds','Wide Receiver','Low',3),(46,'Anthony','Firkser','Tight End','Medium',3),(47,'Taylor','Lewan','Offensive Tackle','High ',3),(48,'Dillon','Radunz','Offensive Tackle','Low',3),(49,'Ben','Jones','Center','Medium',3),(50,'Jeffrey','Simmons','Defensive Tackle','High ',3),(51,'Denico','Autry','Defensive Tackle','Low',3),(52,'Harold','Landry III','Defensive End','Medium',3),(53,'Bud','Dupree','Defensive End','High ',3),(54,'Rashaan','Evans','Linebacker','Low',3),(55,'Jayon','Brown','Linebacker','Medium',3),(56,'Janoris','Jenkins','Cornerback','High ',3),(57,'Caleb','Farley','Cornerback','Low',3),(58,'Kevin','Byard','Safety','Medium',3),(59,'Amani','Hooker','Safety','High ',3),(60,'Sam','Ficken','Kicker','Low',3),(61,'Tom','Brady','Quarterback','Medium',4),(62,'Leonard','Fournette','Running Back','High ',4),(63,'Mike','Evans','Wide Receiver','Low',4),(64,'Chris','Godwin','Wide Receiver','Medium',4),(65,'Antonio','Brown','Wide Receiver','High ',4),(66,'Rob','Gronkowski','Tight End','Low',4),(67,'Donovan','Smith','Offensive Tackle','Medium',4),(68,'Tristan','Wirfs','Offensive Tackle','High ',4),(69,'Ryan','Jensen','Center','Low',4),(70,'Ndamukong','Suh','Defensive Tackle','Medium',4),(71,'Vita','Vea','Defensive Tackle','High ',4),(72,'Jason','Pierre-Paul','Defensive End','Low',4),(73,'Shaq','Barrett','Defensive End','Medium',4),(74,'Lavonte','David','Linebacker','High ',4),(75,'Devin','White','Linebacker','Low',4),(76,'Carlton','Davis','Cornerback','Medium',4),(77,'Sean','Murphy-Bunting','Cornerback','High ',4),(78,'Jordan','Whitehead','Safety','Low',4),(79,'Antoine','Winfield Jr.','Safety','Medium',4),(80,'Ryan','Succop','Kicker','High ',4),(81,'Trevor','Lawrence','Quarterback','Low',5),(82,'James','Robinson','Running Back','Medium',5),(83,'Laviska','Shenault Jr.','Wide Receiver','High ',5),(84,'Marvin','Jones Jr.','Wide Receiver','Low',5),(85,'D.J.','Chark Jr.','Wide Receiver','Medium',5),(86,'Chris','Manhertz','Tight End','High ',5),(87,'Cam','Robinson','Offensive Tackle','Low',5),(88,'Jawaan','Taylor','Offensive Tackle','Medium',5),(89,'Brandon','Linder','Center','High ',5),(90,'Malcolm','Brown','Defensive Tackle','Low',5),(91,'Taven','Bryan','Defensive Tackle','Medium',5),(92,'Josh','Allen','Defensive End','High ',5),(93,'K\'Lavon','Chaisson','Defensive End','Low',5),(94,'Myles','Jack','Linebacker','Medium',5),(95,'Joe','Schobert','Linebacker','High ',5),(96,'Shaquill','Griffin','Cornerback','Low',5),(97,'C.J.','Henderson','Cornerback','Medium',5),(98,'Rayshawn','Jenkins','Safety','High ',5),(99,'Jarrod','Wilson','Safety','Low',5),(100,'Josh','Lambo','Kicker','Medium',5),(101,'Anthony','Walker','Wide Receiver','Low',6),(102,'Austin','Hooper','Tackle','Low',6),(103,'Baker','Mayfield','Defensive Tackle','High ',6),(104,'Blake','Hance','Wide Receiver','Low',6),(105,'Chase','McLaughlin','Wide Receiver','Medium',6),(106,'Chris','Nagy','Offensive Lineman','Low',6),(107,'Cody','Parkey','Cornerback','Low',6),(108,'Creed','Humphrey','Defensive Tackle','Medium',6),(109,'D\'Ernest','Johnson','Wide Receiver','High ',6),(110,'David','Njoku','Defensive Tackle','Low',6),(111,'Demetric','Felton','Wide Receiver','Medium',6),(112,'Denzel','Ward','Cornerback','High ',6),(113,'Donovan','Peoples-Jones','Linebacker','Low',6),(114,'Garrett','Gilbert','Safety','Medium',6),(115,'Greg','Newsome II','Linebacker','Low',6),(116,'Harrison','Bryant','Center','Low',6),(117,'Jack','Conklin','Guard','Medium',6),(118,'Jadeveon','Clowney','Tackle','High ',6),(119,'James','Hudson III','Linebacker','Low',6),(120,'Nick','Harris','Tight End','High ',6),(121,'Kyler','Murray','Quarterback','High ',7),(122,'Chase','Edmonds','Running Back','Low',7),(123,'DeAndre','Hopkins','Wide Receiver','Medium',7),(124,'A.J.','Green','Wide Receiver','High ',7),(125,'Christian','Kirk','Wide Receiver','Low',7),(126,'Maxx','Williams','Tight End','Medium',7),(127,'D.J.','Humphries','Offensive Tackle','High ',7),(128,'Kelvin','Beachum','Offensive Tackle','Low',7),(129,'Rodney','Hudson','Center','Medium',7),(130,'J.J.','Watt','Defensive Tackle','High ',7),(131,'Zach','Allen','Defensive Tackle','Low',7),(132,'Chandler','Jones','Defensive End','Medium',7),(133,'Markus','Golden','Defensive End','High ',7),(134,'Zaven','Collins','Linebacker','Low',7),(135,'Jordan','Hicks','Linebacker','Medium',7),(136,'Robert','Alford','Cornerback','High ',7),(137,'Byron','Murphy Jr.','Cornerback','Low',7),(138,'Budda','Baker','Safety','Medium',7),(139,'Jalen','Thompson','Safety','High ',7),(140,'Matt','Prater','Kicker','Low',7),(141,'Justin','Herbert','Quarterback','Medium',8),(142,'Austin','Ekeler','Running Back','High ',8),(143,'Keenan','Allen','Wide Receiver','Low',8),(144,'Mike','Williams','Wide Receiver','Medium',8),(145,'Jalen','Guyton','Wide Receiver','High ',8),(146,'Jared','Cook','Tight End','Low',8),(147,'Rashawn','Slater','Offensive Tackle','Medium',8),(148,'Bryan','Bulaga','Offensive Tackle','High ',8),(149,'Corey','Linsley','Center','Low',8),(150,'Jerry','Tillery','Defensive Tackle','Medium',8),(151,'Linval','Joseph','Defensive Tackle','High ',8),(152,'Joey','Bosa','Defensive End','Low',8),(153,'Melvin','Ingram III','Defensive End','Medium',8),(154,'Kenneth','Murray','Linebacker','High ',8),(155,'Drue','Tranquill','Linebacker','Low',8),(156,'Michael','Davis','Cornerback','Medium',8),(157,'Asante','Samuel Jr.','Cornerback','High ',8),(158,'Derwin','James','Safety','Low',8),(159,'Nasir','Adderley','Safety','Medium',8),(160,'Michael','Badgley','Kicker','High ',8),(161,'Sam','Darnold','Quarterback','Low',9),(162,'Christian','McCaffrey','Running Back','Medium',9),(163,'D.J.','Moore','Wide Receiver','High ',9),(164,'Robbie','Anderson','Wide Receiver','Low',9),(165,'Terrace','Marshall Jr.','Wide Receiver','Medium',9),(166,'Dan','Arnold','Tight End','High ',9),(167,'Taylor','Moton','Offensive Tackle','Low',9),(168,'Brady','Christensen','Offensive Tackle','Medium',9),(169,'Matt','Paradis','Center','High ',9),(170,'Derrick','Brown','Defensive Tackle','Low',9),(171,'DaQuan','Jones','Defensive Tackle','Medium',9),(172,'Brian','Burns','Defensive End','High ',9),(173,'Hassan','Reddick','Defensive End','Low',9),(174,'Shaq','Thompson','Linebacker','Medium',9),(175,'Jermaine','Carter Jr.','Linebacker','High ',9),(176,'Donte','Jackson','Cornerback','Low',9),(177,'Jaycee','Horn','Cornerback','Medium',9),(178,'Juston','Burris','Safety','High ',9),(179,'Jeremy','Chinn','Safety','Low',9),(180,'Joey','Slye','Kicker','Medium',9),(181,'Deshaun','Watson','Quarterback','High ',10),(182,'David','Johnson','Running Back','Low',10),(183,'Brandin','Cooks','Wide Receiver','Medium',10),(184,'Nico','Collins','Wide Receiver','High ',10),(185,'Randall','Cobb','Wide Receiver','Low',10),(186,'Jordan','Akins','Tight End','Medium',10),(187,'Laremy','Tunsil','Offensive Tackle','High ',10),(188,'Marcus','Cannon','Offensive Tackle','Low',10),(189,'Justin','Britt','Center','Medium',10),(190,'Maliek','Collins','Defensive Tackle','High ',10),(191,'Ross','Blacklock','Defensive Tackle','Low',10),(192,'Whitney','Mercilus','Defensive End','Medium',10),(193,'J.J.','Watt','Defensive End','High ',10),(194,'Zach','Cunningham','Linebacker','Low',10),(195,'Christian','Kirksey','Linebacker','Medium',10),(196,'Terrance','Mitchell','Cornerback','High ',10),(197,'Vernon','Hargreaves III','Cornerback','Low',10),(198,'Justin','Reid','Safety','Medium',10),(199,'Lonnie','Johnson Jr.','Safety','High ',10),(200,'Ka\'imi','Fairbairn','Kicker','Low',10);
/*!40000 ALTER TABLE `player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teams` (
  `id_Team` int NOT NULL AUTO_INCREMENT,
  `teamName` varchar(45) NOT NULL,
  `city` varchar(25) NOT NULL,
  `captain` int DEFAULT NULL,
  `coach` varchar(45) NOT NULL,
  PRIMARY KEY (`id_Team`),
  UNIQUE KEY `teamName_UNIQUE` (`teamName`),
  KEY `Captain_idx` (`captain`),
  CONSTRAINT `Captain` FOREIGN KEY (`captain`) REFERENCES `player` (`id_Player`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (1,'Buffalo Bills','Buffalo',19,'Sean McDermott'),(2,'Cincinnati Bengals','Cincinnati',29,'Zac Taylor'),(3,'Tennessee Titans','Nashville',44,'Mike Vrabel'),(4,'Tampa Bay Buccaneers','Tampa',61,'Bruce Arians'),(5,'Jacksonville Jaguars','Jacksonville',81,'Urban Meyer'),(6,'Cleveland Browns','Cleveland',105,'Kevin Stefanski'),(7,'Arizona Cardinals','Glendale',128,'Kliff Kingsbury'),(8,'Los Angeles Chargers','Los Angeles',147,'Brandon Staley'),(9,'Carolina Panthers','Charlotte',173,'Matt Rhule'),(10,'Houston Texans','Houston',197,'David Culley');
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-28 19:41:07
