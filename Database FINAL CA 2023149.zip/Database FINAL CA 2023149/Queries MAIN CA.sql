/*Query #1 List all captains ID with their first, last name and Team  */
SELECT t.captain, p.firstName, p.lastName, t.teamName
FROM player p
INNER JOIN teams t ON t.id_Team = p.team
WHERE p.id_player = t.captain;

/*Query #2 List all unique positions found in the database*/
SELECT distinct p.position 
FROM player p;

/*Query #3 List all the football players’ names ordered alphabetically in ascending order*/
SELECT  p.lastName, p.firstName, t.teamName
FROM player p
INNER JOIN teams t ON t.id_Team = p.team
ORDER BY p.lastName ASC, p.firstName ASC;

/*Query #4 Count how many teams won, lost or draw on the last matchday*/
SELECT  Count( gr.gameResult), gr.gameResult
FROM gameresults gr
INNER JOIN games g ON gr.game = g.id_Games
WHERE  gameDate > "2022-09-20" AND  gameDate < "2022-09-24"
GROUP BY gameResult;

/*Query #5 Provide the list with all the details of the football players, of the teams that lost the first matchday, 
and sort them by skill level in ascending order*/

SELECT p.* , t.teamName
FROM player p
INNER JOIN gameresults gr ON  gr.team = p.team
INNER JOIN teams t ON t.id_Team = gr.team
INNER JOIN games g ON gr.game = g.id_Games
WHERE  gameDate > "2022-08-27" AND gameDate < "2022-09-03" AND gameResult = "Loss"
ORDER BY skill_Level ASC;

/*Query #6 How many football players with a low skill level had or has an injury? */
SELECT COUNT(p.id_player) AS InjuriesAmount_players, p.skill_Level
FROM player p
INNER JOIN injuriesrecord ir ON ir.id_player = p.id_Player
WHERE skill_Level = "Low"
GROUP BY p.skill_Level;

/*Query #7 How many football players have had more than one injury? Display the information of the football 
player, including the information of the Team (name and city) and they type and the dates of the 
injuries.  */
SELECT  COUNT(ir.id_injury) AS Amount_InjuriesPlayers, p.*, t.teamName, t.city
FROM injuriesrecord ir
INNER JOIN injuries i ON i.id_Injuries = ir.id_injury
INNER JOIN player p  ON ir.id_player = p.id_Player
INNER JOIN teams t ON t.id_Team = p.team
GROUP BY p.id_Player
HAVING Amount_InjuriesPlayers > 1;

SELECT  COUNT(ir.id_injury) AS Amount_InjuriesPlayers, p.*, t.teamName, t.city, injuryType, injuryDate
FROM injuriesrecord ir
INNER JOIN injuries i ON i.id_Injuries = ir.id_injury
INNER JOIN player p  ON ir.id_player = p.id_Player
INNER JOIN teams t ON t.id_Team = p.team
WHERE p.id_Player = "55"
GROUP BY p.id_Player, injuryDate, injuryType;

/*Query #8 Display a list of the most common injuries and order them by ascending order. */
SELECT COUNT(id_injuries) AS Times_Appear, injuryType
FROM injuriesrecord ir
INNER JOIN injuries i ON ir.id_injury = i. id_Injuries
GROUP BY injuryType
HAVING Times_Appear > 1
ORDER BY injuryType ASC;

/*Query #9  Which match date has more draws? Show a list of the teams that have draw that date and their 
score. */
SELECT id_Team, teamName, host_Score, guest_Score, gameResult
FROM teams t
INNER JOIN gameresults gr ON t.id_Team = gr.team
INNER JOIN games g ON  g.id_Games = gr.game
WHERE gameResult = "DRAW" AND gameDate > "2022-09-07" AND gameDate < "2022-09-11";

/*Query #10 Count how many players have a low skill level, medium skill level and high skill level, group them by 
team and sort them in an increasing order.  */
SELECT COUNT(p.id_Player) AS Amount_Players,  p.skill_Level, p.team, t.teamName
FROM player p 
INNER JOIN teams t ON t.id_Team = p.team
GROUP BY team , skill_Level , teamName
ORDER BY Amount_Players ASC;

